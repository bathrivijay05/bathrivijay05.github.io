#include<stdio.h>
#include<conio.h>

int stack[100],n,x,top=-1,i,choice;

void push(void);
void pop(void);
void display(void);

void main() {
   clrscr();
   printf("Enter the number of elements MAX[100]: ");
   scanf("%d",&n);
   printf("\nChoices:\n1.Push\n2.Pop\n3.Display\n4.Exit\n");
   do {
      printf("\nEnter the choice: ");
      scanf("%d",&choice);
      switch(choice) {
	 case 1:
	 push();
	 break;
	 case 2:
	 pop();
	 break;
	 case 3:
	 display();
	 break;
	 case 4:
	 printf("\nProgram exited");
	 break;
	 default:
	 printf("\nInvalid Choice: ");

      }

   } while(choice != 4);
   getch();
}

void push() {
   if(top+1 == n) {
      printf("Overflow\n");
   } else {
      printf("Enter a value: ");
      scanf("%d",&x);
      stack[++top] = x;
      printf("%d is pushed into Stack\n",x);
   }
}

void pop() {
   if(top == -1) {
      printf("Underflow\n");
   } else {
      x = stack[top];
      top--;
      printf("%d is deleted from the Stack\n",x);
   }
}

void display() {
   if(top == -1) {
      printf("No elements found\n");
   } else {
	  printf("The elements are: \n");
      for(i=top;i>=0;i--) {
	 printf("%d\n",stack[i]);
      }
      printf("\n");
   }
}