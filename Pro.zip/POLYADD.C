#include <stdio.h>
#include <stdlib.h>

struct Node {
    int coef;
    int expo;
    struct Node *next;
};

void insertTerm(struct Node **poly, int coef, int expo) {
    struct Node *newTerm = (struct Node *)malloc(sizeof(struct Node));
    newTerm->coef = coef;
    newTerm->expo = expo;
    newTerm->next = *poly;
    *poly = newTerm;
}

struct Node *addPolynomials(struct Node *poly1, struct Node *poly2) {
    struct Node *result = NULL;
    while (poly1 != NULL || poly2 != NULL) {
        struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
        temp->next = result;
        result = temp;

        if (poly1 == NULL) {
            temp->coef = poly2->coef;
            temp->expo = poly2->expo;
            poly2 = poly2->next;
        } else if (poly2 == NULL) {
            temp->coef = poly1->coef;
            temp->expo = poly1->expo;
            poly1 = poly1->next;
        } else {
            if (poly1->expo > poly2->expo) {
                temp->coef = poly1->coef;
                temp->expo = poly1->expo;
                poly1 = poly1->next;
            } else if (poly1->expo < poly2->expo) {
                temp->coef = poly2->coef;
                temp->expo = poly2->expo;
                poly2 = poly2->next;
            } else {
                temp->coef = poly1->coef + poly2->coef;
                temp->expo = poly1->expo;
                poly1 = poly1->next;
                poly2 = poly2->next;
            }
        }
    }
    return result;
}

void displayPolynomial(struct Node *poly) {
    while (poly != NULL) {
        printf("%dx^%d", poly->coef, poly->expo);
        poly = poly->next;
        if (poly != NULL) {
            printf(" + ");
        }
    }
    printf("\n");
}

void freePolynomial(struct Node *poly) {
    struct Node *temp;
    while (poly != NULL) {
        temp = poly;
        poly = poly->next;
        free(temp);
    }
}

int main() {
    struct Node *poly1 = NULL;
    struct Node *poly2 = NULL;
    struct Node *result = NULL;
    int terms, coef, expo;

    printf("Polynomial 1:\n");
    printf("Enter the number of terms: ");
    scanf("%d", &terms);
    for (int i = 0; i < terms; i++) {
        printf("Enter the coef and expo: ");
        scanf("%d %d", &coef, &expo);
        insertTerm(&poly1, coef, expo);
    }

    printf("Polynomial 2:\n");
    printf("Enter the number of terms: ");
    scanf("%d", &terms);
    for (int i = 0; i < terms; i++) {
        printf("Enter the coef and expo: ");
        scanf("%d %d", &coef, &expo);
        insertTerm(&poly2, coef, expo);
    }

    printf("Polynomial 1: ");
    displayPolynomial(poly1);
    printf("Polynomial 2: ");
    displayPolynomial(poly2);

    result = addPolynomials(poly1, poly2);

    printf("Polynomial Addition Result: ");
    displayPolynomial(result);

    freePolynomial(poly1);
    freePolynomial(poly2);
    freePolynomial(result);

    return 0;
}
