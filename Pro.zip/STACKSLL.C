#include<stdio.h>
#include<conio.h>

void push(void);
void pop(void);
void getTop(void);
void display(void);

struct node {
    int data;
    struct node *next;
}*top,*n,*t;

void main() {
    int choice;
    clrscr();
    printf("\nList of Operations:\n");
    printf("1.Push Element\n");
    printf("2.Pop Element\n");
    printf("3.Top Element\n");
    printf("4.Display\n");
    printf("5.Exit\n");

    do {
       printf("\nEnter the choice: ");
       scanf("%d",&choice);
       switch(choice) {
	  case 1:
	  push();
	  break;
	  case 2:
	  pop();
	  break;
	  case 3:
	  getTop();
	  break;
	  case 4:
	  display();
	  break;
	  case 5:
	  printf("Program exited.");
	  break;
	  default:
	  printf("Invalid Choice.");
       }
    } while(choice != 5);
    getch();
}

void push() {
    int value;
    n = (struct node*)malloc(sizeof(struct node));
    printf("Enter a value: ");
    scanf("%d",&value);
    n->next = NULL;
    n->data = value;
    if(top == NULL) {
	top = n;
    } else {
	n->next = top;
	top = n;
    }
    printf("%d is inserted into stack.\n",value);
}

void pop() {
    int value;
    if(top == NULL) {
       printf("Stack underflow.\n");
    } else if(top->next == NULL) {
       value = top->data;
       free(top);
       top = NULL;
       printf("%d is deleted from stack.\n",value);
    } else {
       value = top->data;
       t = top;
       top = t->next;
       free(t);
       printf("%d is deleted from stack.\n",value);
    }
}

void getTop() {
    if(top == NULL) {
       printf("Stack is empty.\n");
    } else {
       printf("Top value is %d.\n",top->data);
    }
}

void display() {
    if(top == NULL) {
	printf("Stack is empty.\n");
    } else {
	t = top;
	while(t != NULL) {
	   printf("%d ",t->data);
	   t = t->next;
	}
	printf("\n");
    }
}