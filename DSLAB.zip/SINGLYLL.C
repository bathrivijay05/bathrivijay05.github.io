#include<stdio.h>
#include<stdlib.h>

void insertAtBegin(void);
void insertAtEnd(void);
void insertAtPos(void);
void deleteFromBegin(void);
void deleteFromEnd(void);
void deleteFromPos(void);
void displayList(void);

struct node {
    int data;
    struct node *next;
}*head,*tail,*t,*n;

void main() {
    int choice;
    printf("List of Operartions:\n");
    printf("1.Insert at Beginning\n");
    printf("2.Insert at End\n");
    printf("3.Insert at a Position\n");
    printf("4.Delete from Beginning\n");
    printf("5.Delete from End\n");
    printf("6.Delete from a Position\n");
    printf("7.Display List\n");
    do {
       printf("\nEnter the choice: ");
       scanf("%d",&choice);
       switch(choice) {
	  case 1:
	  insertAtBegin();
	  break;
	  case 2:
	  insertAtEnd();
	  break;
	  case 3:
	  insertAtPos();
	  break;
	  case 4:
	  deleteFromBegin();
	  break;
	  case 5:
	  deleteFromEnd();
	  break;
	  case 6:
	  deleteFromPos();
	  break;
	  case 7:
	  displayList();
	  break;
	  case 8:
	  printf("Program exited.");
	  break;
	  default:
	  printf("Invalid Choice.");
       }
    } while(choice != 8);
}

void insertAtBegin() {
	int value;
	n = (struct node*)malloc(sizeof(struct node));
	printf("Enter a value: ");
	scanf("%d",&value);
	n->next = NULL;
	n->data = value;
	if(head == NULL) {
	head = n;
	tail = n;
	} else {
	n->next = head;
	head = n;
	}
	printf("%d is inserted into list\n",value);
}

void insertAtEnd() {
	int value;
	n = (struct node*)malloc(sizeof(struct node));
	printf("Enter a value: ");
	scanf("%d",&value);
	n->next = NULL;
	n->data = value;
	if(head == NULL) {
	head = n;
	tail= n;
	} else {
	tail->next = n;
	tail = n;
	}
	printf("%d is inserted into list\n",value);
}

void insertAtPos() {
	int value;
	int pos;
	n = (struct node*)malloc(sizeof(struct node));
	printf("Enter the position: ");
	scanf("%d",&pos);
	printf("Enter the value: ");
	scanf("%d",&value);
	n->data = value;
	if(head == NULL) {
	head = n;
	tail = n;
	} else if(pos == 0) {
		n->next = head;
		head = n;
	} else {
	  struct node *tp;
	  int i = 0;
	  t = head;
	  while(i < pos) {
		 tp = t;
		 t = t->next;
	     i++;
	  }
	  printf("\n%d %d\n",tp->data,t->data);
	  tp->next = n;
	  n->next = t;
    }
    printf("%d is inserted into list\n",value);
}

void deleteFromBegin() {
    int value;
    if(head == NULL) {
       printf("List is empty\n");
    } else if(head->next == NULL) {
       value = head->data;
       free(head);
       head = NULL;
       tail = NULL;
       printf("%d is deleted from list\n",value);
    } else {
       value = head->data;
       t = head;
       head = t->next;
       free(t);
       printf("%d is deleted from list\n",value);
    }
}

void deleteFromEnd() {
    int value;
    if(head == NULL) {
       printf("List is empty\n");
    } else if(head->next == NULL) {
       value = head->data;
       free(head);
       head = NULL;
       tail = NULL;
       printf("%d is deleted from list\n",value);
    } else {
       struct node *tp;
       t = head;
       while(t->next != NULL) {
	  tp = t;
	  t = t->next;
       }
       printf("\nData: %d %d %d\n",tp->data,t->data,tail->data);
	   value = tail->data;
	   tail = tp;
	   tail->next = NULL;
	   free(t);
	   printf("%d is deleted from list\n",value);
	}

}

void deleteFromPos() {
	int value;
	int pos,i=0;
	printf("Enter the position: ");
	scanf("%d",&pos);
	if(head == NULL) {
	   printf("List  is empty\n");
	} else if(pos == 0) {
	   value = head->data;
	   t = head;
	   head = t->next;
	   free(t);
	   printf("%d is deleted from list\n",value);
	} else {
	   struct node *tp;
	   t = head;
	   while(i < pos) {
    	  tp = t;
    	  t = t->next;
    	  i++;
	   }
	   if(t != NULL) {
    	   value = t->data;
    	   printf("\n%d %d\n",tp->data,t->data);
    	   tp->next = t->next;
           if(tp->next == NULL) {
    	        tail = tp;
           }
           free(t);
           printf("%d is deleted from list\n",value);
	   }
    }
}

void displayList() {
    if(head == NULL) {
	printf("List is empty.\n");
    } else {
	t = head;
	while(t != NULL) {
	   printf("%d ",t->data);
	   t = t->next;
	}
	printf("\n");
    }
}