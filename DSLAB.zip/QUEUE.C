/* Implementation of Queue using arrays */
#include<stdio.h>
#include<conio.h>

int queue[100];
int front = -1;
int rear = -1;
int max,x,i;

void enqueue(void);
void dequeue(void);
void display(void);
void isFull(void);
void isEmpty(void);
void peak(void);

void main() {
  int choice;
  clrscr();
  printf("Enter the number of elements MAX[100]: ");
  scanf("%d",&max);
  printf("1. Enqueue\n2. Dequeue\n3. Display\n");
  printf("4. isFull\n5. isEmpty\n6 .Peak\n7. Exit\n");
  do {
    printf("\n\nEnter your choice: ");
    scanf("%d",&choice);
    switch(choice) {
       case 1:
       enqueue();
       break;
       case 2:
       dequeue();
       break;
       case 3:
       display();
       break;
       case 4:
       isFull();
       break;
       case 5:
       isEmpty();
       break;
       case 6:
       peak();
       break;
       case 7:
       printf("Program executed.");
       break;
       default:
       printf("\nInvalid choice.");
       break;
    }
  } while(choice != 7);
  getch();
}

void enqueue() {
   if(rear == max-1) {
       printf("\nOverflow");
   } else if(front == -1 && rear == -1) {
       rear++;
       front++;
       printf("\nEnter a value: ");
       scanf("%d",&x);
       queue[rear] = x;
       printf("\n%d is added into queue.",x);
   } else {
       rear++;
       printf("\nEnter a value: ");
       scanf("%d",&x);
       queue[rear] = x;
       printf("\n%d is added into queue.",x);
   }
}

void dequeue() {
   if(front == -1 && rear == -1) {
       printf("\nUnderflow");
   } else if(front == rear) {
       x = queue[front];
       front = -1;
       rear = -1;
       printf("\n%d is removed from the queue.",x);
   } else {
       x = queue[front];
       front++;
       printf("\n%d is removed from the queue.",x);
   }
}

void display() {
   if(front == -1 && rear == -1) {
      printf("\nQueue is empty.");
   } else {
      printf("\nThe elements of queue are:\n");
      for(i=front;i<=rear;i++) {
	   printf("%d ",queue[i]);
      }
   }
}

void isFull() {
   if(rear == max-1) {
       printf("\nQueue is full.");
   } else {
       printf("\nQueue is not full.");
   }
}

void isEmpty() {
   if(front == -1 && rear == -1) {
       printf("\nQueue is empty");
   } else {
       printf("\nQueue is not empty");
   }
}

void peak() {
  if(front == -1 && rear == -1) {
       printf("\nQueue is empty");
  } else {
       printf("\n%d is the Peak element",queue[front]);
  }
}