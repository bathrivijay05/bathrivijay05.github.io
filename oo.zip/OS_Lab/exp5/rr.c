#include <stdio.h>
struct process {
    int pn, bt, wt, tat;
} p[10];
void main() {
    int tq, i, j = 0, n, b[10], ttat = 0;
    float awt = 0, atat = 0;
    printf("\nEnter no. of processes: ");
    scanf("%d", &n);
    printf("\nEnter input:\nP.No\tBurst Time\n");
    for (i = 1; i <= n; i++) {
        scanf("%d %d", &p[i].pn, &p[i].bt);
        b[i] = p[i].bt;
        ttat = ttat + p[i].bt;
    }
    printf("\nEnter time quantum: ");
    scanf("%d", &tq);
    while (j < ttat) {
        for (i = 1; i <= n; i++) {
            if (p[i].bt != 0) {
                if (p[i].bt > tq) {
                    p[i].bt = p[i].bt - tq;
                    j = j + tq;
                } else {
                    j = j + p[i].bt;
                    p[i].tat = j;
                    p[i].wt = p[i].tat - b[i];
                    atat = atat + p[i].tat;
                    awt = awt + p[i].wt;
                    p[i].bt = 0;
                }
            }
        }
    }
    printf("\nP.No\tBurst\tWait\tTurn");
    for (i = 1; i <= n; i++) {
        printf("\n%d\t%d\t%d\t%d", p[i].pn, b[i], p[i].wt, p[i].tat);
    }
    printf("\n\nAvg waiting time is %f", awt / n);
    printf("\nAvg turn around time is %f", atat / n);
}
