#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

char n[1024];
sem_t len;

void *read1(void *arg) {
    while (1) {
        printf("\nEnter a string: ");
        fgets(n, sizeof(n), stdin);
        sem_post(&len);
        memset(n, 0, sizeof(n));
    }
    return NULL;
}

void *write1(void *arg) {
    while (1) {
        sem_wait(&len);
        printf("\nThe string entered is: %s", n);
    }
    return NULL;
}

int main() {
    int status;
    pthread_t tr, tw;
    if (sem_init(&len, 0, 0) != 0) {
        perror("Semaphore initialization failed");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&tr, NULL, read1, NULL) != 0) {
        perror("Thread creation failed");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&tw, NULL, write1, NULL) != 0) {
        perror("Thread creation failed");
        exit(EXIT_FAILURE);
    }
    pthread_join(tr, NULL);
    pthread_join(tw, NULL);
    return 0;
}

