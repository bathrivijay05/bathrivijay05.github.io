#include <math.h>
#include <stdio.h>
void main() {
    int m, n, f[10], i, d[10], la, pa, p;
    printf("enter values m and n:\n");
    scanf("%d%d", &m, &n);
    la = pow(2, m);
    pa = pow(2, n);
    p = la / pa;
    printf("size of logical addr is %d bytes\n", la);
    printf("size of physical addr is %d bytes\n", pa);
    for (i = 0; i < p; i++) {
        printf("enter the page no. and offset of page %d: ", i);
        scanf("%d%d", &f[i], &d[i]);
    }
    printf("\nPAGE MAP TABLE\n");
    printf("page #\tframe #\n");
    for (i = 0; i < n; i++) printf("%d\t %d\n", i, f[i]);
    for (i = 0; i < p; i++)
        printf("physical addr of page %d is:%d\n", i, (f[i] * pa + d[i]));
}
