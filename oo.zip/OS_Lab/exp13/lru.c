#include <stdio.h>
void main() {
    int n, i, j, f, q[20], p[20], pgf = 0, st = 0, t, cnt;
    printf("enter no. of ref strings:\n");
    scanf("%d", &n);
    printf("enter no. of frames:\n");
    scanf("%d", &f);
    printf("enter strings:\n");
    for (i = 0; i < n; i++) scanf("%d", &q[i]);
    for (i = 0; i < f; i++) p[i] = 999;
    for (i = 0; i < n; i++) {
        for (j = 0; j < f; j++)
            if (p[j] == q[i]) {
                st++;
                t = p[j];
                cnt = j;
            }
        if (st == 0) {
            printf("\nFault \n");
            pgf++;
            for (j = f; j > 0; j--) p[j] = p[j - 1];
            p[0] = q[i];
        } else {
            printf("\n");
            for (j = cnt; j > 0; j--) p[j] = p[j - 1];
            p[0] = t;
            st = 0;
        }
        for (j = 0; j < f; j++) printf("%d\t", p[j]);
    }
    printf("\nTot pag fault is %d", pgf);
}

