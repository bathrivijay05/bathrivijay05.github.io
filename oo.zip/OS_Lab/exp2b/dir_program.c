#include<sys/types.h>
#include<dirent.h>
#include<stdio.h>
main(int c,char* arg[])
{
	DIR *d;
	struct dirent *r;
	int i=0;
	d=opendir(arg[1]);
	printf("\nNAME OF ITEM \n");
	while((r=readdir(d)) != NULL)
	{
		printf("\t %s \n",r->d_name);
		i=i+1;
	}
	printf("\nTOTAL NUMBER OF ITEM IN THAT DIRECTORY IS %d \n",i);
}
